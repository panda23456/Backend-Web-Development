const pool = require("../services/db");

const SQLSTATEMENT = `
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Task;
DROP TABLE IF EXISTS TaskProgress;
DROP TABLE IF EXISTS UserPoints;
DROP TABLE IF EXISTS Pet;
DROP TABLE IF EXISTS PetAbility;
DROP TABLE IF EXISTS PetUserRelationship;
DROP TABLE IF EXISTS Account;
DROP TABLE IF EXISTS UserAccountRel;
DROP TABLE IF EXISTS Messages;

CREATE TABLE User (
  user_id INT PRIMARY KEY AUTO_INCREMENT,
  username TEXT NOT NULL
);

CREATE TABLE Task (
  task_id INT PRIMARY KEY AUTO_INCREMENT,
  title TEXT,
  description TEXT,
  points INT
);

CREATE TABLE TaskProgress (
  progress_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  task_id INT NOT NULL,
  completion_date TIMESTAMP,
  notes TEXT
);

CREATE TABLE UserPoints (
  user_id INT PRIMARY KEY AUTO_INCREMENT,
  total_points INT DEFAULT 0
);

CREATE TABLE Pet (
  pet_id INT PRIMARY KEY AUTO_INCREMENT,
  name TEXT,
  level INT DEFAULT 0,
  cost INT
);

CREATE TABLE PetAbility (
  ability_id INT PRIMARY KEY AUTO_INCREMENT,
  level INT,
  name TEXT,
  description TEXT
);

CREATE TABLE PetUserRelationship (
  relationship_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  pet_id INT,
  pet_level INT,
  ability_id INT
);

CREATE TABLE Account (
  account_id INT PRIMARY KEY AUTO_INCREMENT,
  username TEXT NOT NULL,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  created_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE UserAccountRel (
  id INT PRIMARY KEY AUTO_INCREMENT,
  account_id INT NOT NULL,
  user_id INT NOT NULL
);

CREATE TABLE Messages (
  message_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  message_text TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Task (title, description, points) VALUES
('Plant a Tree', 'Plant a tree in your neighbourhood or a designated green area.', 50),
('Use Public Transportation', 'Use public transportation or carpool instead of driving alone.', 30),
('Reduce Plastic Usage', 'Commit to using reusable bags and containers.', 40),
('Energy Conservation', 'Turn off lights and appliances when not in use.', 25),
('Composting', 'Start composting kitchen scraps to create natural fertilizer.', 35);

INSERT INTO Pet (name, level, cost) VALUES
('Fluffy', 1, 10),
('Spot', 2, 15),
('Whiskers', 3, 20),
('Mittens', 1, 12),
('Shadow', 2, 18),
('Cleo', 3, 25),
('Buddy', 1, 11),
('Oreo', 2, 16),
('Tiger', 3, 22),
('Snowball', 1, 13),
('Simba', 2, 19),
('Pumpkin', 3, 27),
('Rocky', 1, 14),
('Cupcake', 2, 17),
('Max', 3, 23),
('Misty', 1, 12),
('Spike', 2, 20),
('Luna', 3, 26),
('Charlie', 1, 15),
('Gizmo', 2, 21),
('Princess', 3, 29);

INSERT INTO PetAbility (level, name, description) VALUES
  (1, 'Bite', 'Basic biting ability'),
  (2, 'Fire Breath', 'Breathes fire at opponents'),
  (3, 'Teleportation', 'Can teleport short distances');
`;



pool.query(SQLSTATEMENT, (error, results, fields) => {
  if (error) {
    console.error("Error creating tables:", error);
  } else {
    console.log("Tables created successfully:", results);
  }
  process.exit();
});



