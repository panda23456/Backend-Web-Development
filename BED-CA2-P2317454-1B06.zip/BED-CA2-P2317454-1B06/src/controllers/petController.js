/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/petModel.js");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR CREATE NEW PET
// ##############################################################
module.exports.createPet = (req, res, next) =>
{
    if(req.body.name == undefined || req.body.level== undefined || req.body.cost == undefined)
    {
        res.status(400).send({"message": "Missing required data"});
        return;
    }

    const data = {  
        name: req.body.name,
        level: req.body.level,
        cost: req.body.cost
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error createNewPet:", error);
            res.status(500).json({"message": "Internal server error"});
        } else {
            res.status(201).json({"pet_id": results.insertId,
                                  "name" : data.name,
                                  "level": data.level,
                                  "cost": data.cost});
        }
    }

    model.insertPetQuery(data, callback);
}

//##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ ALL PETS
// ##############################################################
module.exports.readAllPet = (req, res, next) =>
{
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readAllPets:", error);
            res.status(500).json(error);
        } 
        else res.status(200).json(results);
    }

    model.selectAllPets(callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ PET BY ID
// ##############################################################
module.exports.readPetById = (req, res, next) =>
{
    const data = {
        pet_id: req.params.pet_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readPetById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "Pet not found"
                });
            }
            else res.status(200).json(results[0]);
        }
    }

    model.selectById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR UPDATE TASK BY ID
// ##############################################################
module.exports.updatePetById = (req, res, next) =>
{
    if(req.body.name == undefined || req.body.level == undefined || req.body.cost == undefined)
    {
        res.status(400).json({
            message: "Missing required data"
        });
        return;
    }

    const data = {  
        pet_id: req.params.pet_id,
        name: req.body.name,
        level: req.body.level,
        cost: req.body.cost
    }

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error updatePetById:", error);
            res.status(500).json(error);
        } else {
            if(results.affectedRows == 0) 
            {
                res.status(404).json({
                    message: "Pet not found"
                });
            }
            else res.status(200).send(); // 204 No Content
        }
    }

    model.updateById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION DELETE TASK BY ID
// ##############################################################
module.exports.deletePetById = (req, res, next) =>
{
    const data = {
        pet_id: req.params.pet_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deletePetById:", error);
            res.status(500).json(error);
        } else {
            if(results[0].affectedRows == 0) 
            {
                res.status(404).json({
                    message: "Pet not found"
                });
            }
            else res.status(204).send(); // 204 No Content            
        }
    }

    model.deleteById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR CHECK IF PET EXIST
// ##############################################################
module.exports.checkIfPetExist = (req, res, next) =>
{
    const data = {
        pet_id: req.params.pet_id,
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readPetById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "Pet not found"
                });
            }
            else {
                next();
            }; 
        }
    }

    model.checkIfPetExistQuery(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR CHECK IF VALID LEVEL
// ##############################################################
module.exports.checkIfValidLevel = (req, res, next) => {
    const data = {
        pet_id: req.params.pet_id,
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error checkIfValidLevel:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "Cannot level"
                });
            }
            else {
                next();
            }; 
        }
    }

    model.checkIfValidLevelQuery(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FEED PET
// ##############################################################
module.exports.feedPet = (req, res, next) => {
    const data = {
        user_id: req.params.user_id,
        pet_id: req.params.pet_id,
    }
    
    const callback = (error, results, fields) => {
         res.status(200).send("Feed success"); // 204 No Content
        }
    

    model.feedPetQuery(data, callback);
}
