/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/taskProgressModel.js");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR CREATE NEW TASK PROGRESS
// ##############################################################
module.exports.checkTaskProgress = (req, res, next) => {
    if (
        req.body.user_id === undefined ||
        req.body.task_id === undefined ||
        req.body.notes === undefined
    ) {
        res.status(400).json({ "message": "Missing required data" });
        return;
    }

    // Check if completion_date is missing or undefined
    if (req.body.completion_date === undefined) {
        res.status(400).json({ "message": "Completion date is required" });
        return;
    }

    const data = {
        user_id: req.body.user_id,
        task_id: req.body.task_id,
        completion_date: req.body.completion_date,
        notes: req.body.notes
    };

    const checkIdsCallback = (error, results, fields) => {
        // console.log(data)
        if (error) {
            console.error("Error checkTaskIds:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            // Check if user_id and task_id exist
            if (results[0].length === 0 || results[1].length === 0) {
                res.status(404).json({ "message": "User_id or Task_id not found" });
            } else {
                // If user_id and task_id exist, proceed with the insert
                res.locals.data = data
                next();
                
            }
        }
    };

    model.checkTaskIds(data, checkIdsCallback);
};

module.exports.addTaskProgress = (req, res, next) => {
    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(data) 
        res.status(201).json({
            "progress_id": results.insertId,
            "user_id": data.user_id,
            "task_id": data.task_id,
            "completion_date": data.completion_date,
            "notes": data.notes
        });
        res.locals.data = data;
        next();
    }

model.insertTask(data, callback)
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ TASK PROGRESS BY ID
// ##############################################################
module.exports.readTaskProgressById = (req, res, next) =>
{
    const data = {
        id: req.params.progress_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readTaskProgressById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "Task Progress not found"
                });
            }
            else res.status(200).json(results[0]);
        }
    }

    model.selectById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR UPDATE TASK PROGRESS BY ID
// ##############################################################
module.exports.updateTaskProgressById = (req, res, next) =>
{
    if(req.body.notes == undefined) {
        res.status(400).json({
            message: "Missing required data"
        });
        return;
    }

    const data = {
        progress_id : req.params.progress_id,
        notes: req.body.notes
        
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error updateTaskProgressById:", error);
            res.status(500).json(error);
        } else {
            if(results.affectedRows == 0) 
            {
                res.status(404).json({
                    message: "Task Progress not found"
                });
            }
            else res.status(200).send(); // 200
        }
    }

    model.updateById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION DELETE TASK PROGRESS BY ID
// ##############################################################
module.exports.deleteTaskProgressById = (req, res, next) =>
{
    const data = {
        progress_id: req.params.progress_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deleteTaskById:", error);
            res.status(500).json(error);
        } else {
            if(results[0].affectedRows == 0) 
            {
                res.status(404).json({
                    message: "Task Progress not found"
                });
            }
            else res.status(204).send(); // 204 No Content            
        }
    }

    model.deleteById(data, callback);
}


//MIDDLEWARE TO GET FROM TASK COMPLETED IN TASK PROGRESS//
module.exports.getTaskPoints = (req, res, next) =>
{
    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(results[0].points);
        
        res.locals.data = data;
        res.locals.points = results[0].points
        next();
    }

model.getPoints(data, callback)

}


//MIDDLEWARE TO ADD TASK POINTS TO USER POINTS
module.exports.addTaskPoints = (req, res, next) =>
{
    const data = res.locals.data
    const points = res.locals.points

    const callback = (error, results, fields) => {
        console.log(points);
    }

model.addPoints(data, points, callback)
}



