/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/authorizeModel.js");

//CONTROLLER TO CHECK IF USER BELONGS TO ACCOUNT//
module.exports.checkUserAccountRel = (req, res, next) => {
    let data = {};

    if (res.locals.user_id) {
        data = {
            user_id: res.locals.user_id,
            account_id : res.locals.account_id,
            username: res.locals.username
        }
    }
    else {
    data = {
        user_id: req.params.user_id,
        account_id : res.locals.account_id,
        username: res.locals.username
    }
}


    const callback = (error, results, fields) => {
        // console.log(results);
        if (error) {
            console.error("Error checkIfUserBelongsToAccount:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "User does not belong to Account"
                });
            }
            else res.status(200).json(results[0]);
        }
    };

    model.checkUserAccountRelQuery(data, callback);
};

//GET USER ID BY RELATIONSHIP ID
module.exports.getUserIdByRelId = (req, res, next) => {
    const data = {
        relationship_id: req.params.relationship_id
    }

    const callback = (error, results, fields) => {
        // console.log(results)
        if (error) {
            console.error("Error getUserIdByRelationshipId:", error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    message: "User ID not found"
                });
            }
            else {
                res.locals.user_id = results[0].user_id;
                next();
                
            }
        }
    
    }

    model.selectUserIdByRelationshipId(data, callback);
}