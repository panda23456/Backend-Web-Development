/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/messageModel.js");

//CONTROLLER TO READ ALL MESSAGES
module.exports.readAllMessage = (req, res, next) => {
    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readAllMessage:", error);
            res.status(500).json(error);
        } else {
            if (results.length == 0) {
                res.status(404).json({"message": "No messages posted"})
            }
            else {
            res.status(200).json(results);
            }
        }
    }

    model.selectAllMessages(callback);
}

//CONTROLLER TO CREATE NEW MESSAGE FOR SPECIFIC USERID
module.exports.createMessage = (req, res, next) => {
    if(req.body.message_text == undefined || req.body.message_text == "")
    {
        res.status(400).send("Error: message_text is undefined");
        return;
    }
    else if(req.body.user_id == undefined)
    {
        res.status(400).send("Error: user_id is undefined");
        return;
    }

    const data = {
        user_id: req.body.user_id,
        message_text: req.body.message_text
    }

    console.log("data", data);

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error createMessage:", error);
            res.status(500).json(error);
        } else {
            res.status(201).json(results);
        }
    }

    model.insertSingle(data, callback);
}

//CONTROLLER TO READ ALL MESSAGES SENT BY SPECIFIC USER
module.exports.readMessageByUserId = (req, res, next) => {
    const data = {
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error readMessageById:", error);
            res.status(500).json(error);
        } else {
            if(results.length == 0) 
            {
                res.status(404).json({
                    message: "Message not found"
                });
            }
            else res.status(200).json(results);
        }
    }

    model.selectById(data, callback);
}

//CONTROLLER FOR DELETE MESSAGE BY ID
module.exports.deleteMessageById = (req, res, next) => {
    const data = {
        message_id: req.params.message_id
    }

    // console.log("Message ID "+ data.message_id)

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deleteMessageById:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({message: "Message ID not found"});
            }
            else {
            res.status(200).json({message: "Message deleted succesfully"});
            }
        }
    }

    model.deleteById(data, callback);
}

//CONTROLLER TO UPDATE MESSAGE
module.exports.updateMessageById = (req, res, next) => {
    if(req.params.message_id == undefined)
    {
        res.status(400).send("Error: id is undefined");
        return;
    }
    else if(req.body.message_text == undefined || req.body.message_text == "")
    {
        res.status(400).send("Error: message_text is undefined or empty");
        return;
    }
    else if(req.body.user_id == undefined)
    {
        res.status(400).send("Error: userId is undefined");
        return;
    }

    const data = {
        message_id: req.params.message_id,
        user_id: req.body.user_id,
        message_text: req.body.message_text
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error updateMessageById:", error);
            res.status(500).json(error);
        } else {
            res.status(201).json({message: "Message succesfully updated"});
        }
    }

    model.updateById(data, callback);
}