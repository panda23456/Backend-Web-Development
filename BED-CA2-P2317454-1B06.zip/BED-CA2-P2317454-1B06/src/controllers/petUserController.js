/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/petUserModel.js");

//MIDDLEWARE FUNCTION TO CHECK IF USER AND PET ID ARE VALID//
// ##############################################################
// DEFINE CONTROLLER FUNCTION BUY PET
// ##############################################################
module.exports.checkValidPetAndUser = (req, res, next) => {

    const data = {
        user_id: req.params.user_id,
        pet_id: req.params.pet_id,
    }

    const callback = (error, results, fields) => {
        console.log(results);
        if (error) {
            console.error("Error checkValidPetAndUser:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            // Check if user_id and task_id exist
            if (results[0].length === 0 || results[1].length === 0) {
                res.status(404).json({ "message": "User_id or Pet_id not found" });
            } else {
                // If user_id and task_id exist, proceed with the insert
                res.locals.data = data
                next();
            }
        }
    };

    model.checkPetAndUserQuery(data, callback);
};

//MIDDLEWARE TO CHECK IF USER CAN AFFORD SELECTED PET
module.exports.checkCost = (req, res, next) => {

    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            res.status(500).json({ "message": "Internal server error" });
        } else {
            // Assuming results[0] is the user details and results[1] is the pet details
            if (results[0].length == 0) {
                res.status(404).json({"message": "Insufficient points, User has not completed any task"});
                
            } else {
                const userPoints = results[0][0].total_points; // Assuming total_points is the column name for points in UserPoints table
                const petCost = results[1][0].cost; // Assuming cost is the column name for cost in Pet table

                if (userPoints < petCost) {
                    res.status(403).json({ "message": "Insufficient points to buy the pet" });
                } else {
                    // If user can afford the pet, proceed with the insert
                    console.log("User Can afford pet")
                    res.locals.data = data;
                    next();
                }   
            }
        }
    };

    model.checkCostQuery(data, callback)

}

//CONTROLLER FOR USER TO BUY AND OWN PET
module.exports.buyPet = (req, res, next) => {
    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error buyPet:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            res.status(200).json({ "message": "Pet bought successfully" });
        }
    };

    model.buyPetQuery(data, callback);
};

//MIDDLEWARE TO CHECK IF RELATIONSHIP ID AND USER ID IS VALID
module.exports.checkValidRelationshipAndUser = (req, res, next) => {

    const data = {
        user_id: req.params.user_id,
        relationship_id: req.params.relationship_id,
    }

    const callback = (error, results, fields) => {
        console.log(results);
        if (error) {
            console.error("Error checkValidRelationshipAndUser:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            // Check if user_id and relationship_id exist
            if (results[0].length === 0 || results[1].length === 0) {
                res.status(404).json({ "message": "User_id or Relationship_id not found" });
            } else {
                // If user_id and realtionship_id exist, proceed with the insert
                res.locals.data = data
                next();
            }
        }
    };

    model.checkRelationshipAndUserQuery(data, callback);
};

//MIDDLEWARE TO CHECK IF USER HAS ENOUGH MONEY TO FEED PET
module.exports.checkFeedCost = (req, res, next) => {

    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            res.status(500).json({ "message": "Internal server error" });
        } else {
            // if (results.length == 0) {
            //     res.status(404).json({
            //         "message": "User does not exist or User has not completed any task"
            //     })
            // }
            // Assuming results[0] is the user details and results[1] is the pet details
            const userPoints = results[0].total_points; // Assuming total_points is the column name for points in UserPoints table
            const feedCost = 10;// Feeding a pet cost 10 money

            if (userPoints < feedCost) {
                res.status(403).json({
                    "message": "Insufficient points to feed the pet",
                    "User Points Remaining": userPoints
                });
            } else {
                // If user can afford the pet, proceed with the insert
                console.log("User has enough money to feed pet", userPoints)
                // res.status(200).json({ "message": "User can afford pet" })
                res.locals.data = data;
                next();

            }
        }
    };

    model.checkFeedCostQuery(data, callback)
}

//MIDDLEWARE TO CHECK IF PET ALREADY REACHED MAX LEVEL
module.exports.isPetMaxed = (req, res, next) => {

    const data = res.locals.data;

    const callback = (error, results, fields) => {
        console.log(results[0].pet_level, results[0].ability_id)
        if (error) {
            console.error("Error isPetMaxed:", error);
            res.status(500).json(error);
        } else{
                const existingPet = results[0];
                if (existingPet.pet_level == 3 || existingPet.ability_id == 3) {
                    res.status(409).json({"message": "Pet cannot level up further"})
                }
                else{
                    res.locals.data = data
                    next();
                }
        }
    }

    model.isPetMaxedQuery(data, callback);
}
//MIDDLEWARE TO CHECK IF USER HAS ENOUGH MONEY TO FEED PET
module.exports.feedPet = (req, res, next) => {
    const data = res.locals.data

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error feedPet:", error);
            res.status(500).json({ "message": "Internal server error" });
        } else {
            res.status(200).json({ "message": "Pet fed successfully" });
        }
    };

    model.feedPetQuery(data, callback);
}

//CONTROLLER FOR getAllPetByUserId
module.exports.getAllPetByUserId = (req, res, next) => {
    const data = {
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error getAllPetByUserId:", error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    message: "User does not own any pets"
                });
            }
            else {
                res.status(200).json(results);
                
            }
        }
    
    }

    model.selectAllPetByUserId(data, callback);
}

//DELETE PET BY RELATIONSHIP ID

module.exports.deletPetByRelationshipId = (req, res, next) => {
    const data = {
        relationship_id: req.params.relationship_id
    }

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error deletePetByRelationshipId:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    message: "Relationship ID does not exist"
                });
            }
            else res.status(200).send({message: "Pet deleted succesfully"});            
        }
    }

    model.deleteByRelationshipId(data, callback);
}

//GET USER ID BY RELATIONSHIP ID
module.exports.getUserIdByRelationshipId = (req, res, next) => {
    const data = {
        relationship_id: req.params.relationship_id
    }

    const callback = (error, results, fields) => {
        // console.log(results)
        if (error) {
            console.error("Error getUserIdByRelationshipId:", error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    message: "User ID not found"
                });
            }
            else {
                res.status(200).json(results);
                
            }
        }
    
    }

    model.selectUserIdByRelationshipId(data, callback);
}