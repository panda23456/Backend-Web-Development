/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/usersModel.js");

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR ADD USER
// ##############################################################
// ... (other imports)
module.exports.checkUser = (req, res, next) => {
    if (req.body.username === undefined) {
        res.status(400).json({ "message": "Missing required data" });
        return;
    }

    const data = {
        username: req.body.username,
        // email: req.body.email,
    };

    const callback = (error, results, fields) => {
        console.log(data)
        if (error) {
            console.error("Error checkUser:", error);
            res.status(500).json(error);
        } else {
            if (results.length > 0) //if results.length > 0, username is duplicated
            {
                const existingUser = results[0];
                const duplicateFields = [];

                if ((existingUser.username).toUpperCase() === (data.username).toUpperCase()) {
                    duplicateFields.push('Username is duplicated')
                }//compare exisiting and input username

                // if ((existingUser.email).toUpperCase() === (data.email).toUpperCase()) {
                //     duplicateFields.push('Email is duplicated')
                // }//comapre existing and input email

                res.status(409).json({
                    message: duplicateFields
                });
                return;
            }
            else {
                res.locals.data = data
                // console.log("Email and username are unique")
                next();
            };
        }
    }

    model.checkUserQuery(data, callback);
}

module.exports.addUser = (req, res, next) => {

    const data = res.locals.data

    const callback = (error, results) => {
        if (error) {
            console.error("Error addUser:", error);
            res.status(500).json({"message": "Internal server error"});
        } else {
            // Upon successful creation, include the newly generated user_id in the response
            res.status(201).json({
                "user_id": results.insertId,
                "username": data.username
            });
        }
    };

    model.addUser(data, callback);
};

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ ALL USERS
// ##############################################################
module.exports.readAllUsers = (req, res, next) => {
    const callback = (error, results, fields) => {
        // console.log(results)
        if (error) {
            console.error("Error readAllPlayer:", error);
            res.status(500).json(error);
        }
        else res.status(200).json(results);
    }

    model.selectAllUsers(callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR READ USERS BY ID
// ##############################################################
module.exports.readUserById = (req, res, next) => {
    const data = {
        user_id: req.params.user_id,
    }

    const callback = (error, results, fields) => {
        // console.log(typeof(results[0].total_points))
        // console.log(results[0].total_points, results[0].total_points);
        if (error) {
            console.error("Error readUserById:", error);
        } else {
            if (results.length == 0) {
                res.status(404).json({
                    message: "User not found"
                });
            }
            else {
                if(results[0].total_points === null) { 
                    results[0].total_points = 0;
                }
                res.status(200).json(results[0]);
                
            }
        }
    
    }

    model.selectById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION FOR UPDATE USER BY ID
// ##############################################################
module.exports.updateUserById = (req, res, next) => {
    if (req.body.username == undefined || req.params.user_id == undefined) {
        res.status(400).json({
            message: "Missing required data"
        });
        return;
    }

    const data = res.locals.data;
    data.user_id = req.params.user_id;

    const callback = (error, results, fields) => {
        console.log(results)
        if (error) {
            console.error("Error updateUserById:", error);
            res.status(500).json(error);
        } else {
            if (results.affectedRows == 0) {
                res.status(404).json({
                    message: "User not found"
                });
            }
            else res.status(201).json({
                "user_id": data.user_id,
                "username": data.username
            });; // 201 
        }
    }

    model.updateById(data, callback);
}

// ##############################################################
// DEFINE CONTROLLER FUNCTION DELETE USER BY ID
// ##############################################################
module.exports.deleteUserById = (req, res, next) => {
    const data = {
        user_id: req.params.user_id
    }

    const callback = (error, results, fields) => {
        if (error) {
            console.error("Error deleteUserById:", error);
            res.status(500).json(error);
        } else {
            if (results[0].affectedRows == 0) {
                res.status(404).json({
                    message: "User not found"
                });
            }
            else res.status(200).send({message: "User deleted succesfully"}); // 204 No Content            
        }
    }

    model.deleteById(data, callback);
}