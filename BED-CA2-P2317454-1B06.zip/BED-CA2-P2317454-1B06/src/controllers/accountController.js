/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const model = require("../models/accountModel.js");

//////////////////////////////////////////////////////
// CONTROLLER FOR LOGIN
//////////////////////////////////////////////////////
module.exports.login = (req, res, next) => {
  if (req.body.username == undefined || req.body.password == undefined) {
    res.status(400).json({
      message: "Error: username or password is undefined",
    });
    return;
  }

  const data = {
    username: req.body.username
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error login:", error);
      res.status(500).json(error);
    } else {
      if (results.length == 0) {
        res.status(404).json({
          message: "User not found",
        });
      } else {
        res.locals.account_id = results[0].account_id;
        res.locals.username = results[0].username;
        res.locals.hash = results[0].password;
        res.locals.message = "User " + res.locals.username + " logged in successfully.";
        next();
      }
    }
  };

  model.selectUserByUsername(data, callback);
};

//////////////////////////////////////////////////////
// CONTROLLER FOR REGISTER
//////////////////////////////////////////////////////
module.exports.register = (req, res, next) => {
  if (
    req.body.username == undefined ||
    req.body.email == undefined ||
    req.body.password == undefined
  ) {
    res.status(400).send("Error: username is undefined");
    return;
  }

  const data = {
    username: req.body.username,
    email: req.body.email,
    password: res.locals.hash,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error register:", error);
      res.status(500).json(error);
    } else {
      res.locals.account_id = results.insertId;
      res.locals.username = req.body.username;
      res.locals.message = "User " + req.body.username + " created successfully.";
      next();
    }
  };

  model.insertUser(data, callback);
};

//////////////////////////////////////////////////////
// MIDLEWARE CONTROLLER FOR CHECK IF USERNAME EXISTS
//////////////////////////////////////////////////////
module.exports.checkUsernameOrEmailExist = (req, res, next) => {
  if (req.body.username == undefined || req.body.email == undefined) {
    res.status(400).send("Error: username or email is undefined");
    return;
  }

  const data = {
    username: req.body.username,
    email: req.body.email,
  };

  const callback = (error, results, fields) => {
    if (error) {
      console.error("Error checkUsernameOrEmailExist:", error);
      res.status(500).json(error);
    } else {
      if (results.length > 0) {
        res.status(409).json({
          message: "Username or email already exists",
        });
      } else next();
    }
  };

  model.selectUserByUsernameOrEmail(data, callback);
}

//CONTROLLER TO GET ALL ACCOUNTS//
module.exports.getAllAccounts = (req, res, next) => {
  const callback = (error, results, fields) => {
    // console.log(results)
    if (error) {
      console.error("Error getAllAccounts:", error);
      res.status(500).json(error);
    }
    else {
      if (results.length == 0) {
        res.status(404).json({"message": "No accounts are created"});
      }
      else {
        res.status(200).json(results);
      }
    }
  }

  model.selectAllAccounts(callback);
}


//CONTROLLER TO update UserAccountRel//
module.exports.addUserAccountRel = (req, res, next) => {

  if (req.body.account_id == undefined || req.body.user_id == undefined) {
    res.status(400).json({
      message: "Missing required data"
    });
    return;
  }

  const data = {
    account_id : req.body.account_id,
    user_id: req.body.user_id
  }

  const callback = (error, results) => {
    console.log(data)
    // console.log(results)
    if (error) {
        console.error("Error addUserAccountRel:", error);
        res.status(500).json({"message": "Internal server error"});
    } else {
        // Upon successful creation, include the newly generated user_id in the response
        res.status(201).json({
            "UserAccountRel ID": results.insertId,
            "account_id": data.account_id,
            "user_id": data.user_id
        });
    }
};

  model.addUserAccountRelQuery(data, callback);

}

//CONTROLLER FOR GET USERACCOUNTREL BY ID
module.exports.getUserAccountRelById = (req, res, next) => {
  const data = {
    account_id: req.params.account_id,
}

const callback = (error, results, fields) => {
    console.log(results)
    if (error) {
        console.error("Error getUserAccountRelById:", error);
    } else {
        if (results.length == 0) {
            res.status(404).json({
                message: "Account does not have any users"
            });
        }
        else {
            res.status(200).json(results);
            
        }
    }

}

model.getUserAccountRelByIdQuery(data, callback);
}
// //CONTROLLER FOR SELECT ACCOUNT BY EMAIL//\
// module.exports.getAccountIdByEmail = (req, res, next) =>
// {
//     const data = {
//         email: req.params.email
//     }

//     const callback = (error, results, fields) => {
//       // console.log(results)
//         if (error) {
//             console.error("Error getAccountIdByEmail:", error);
//             res.status(500).json(error);
//         } else {
//             if(results.length == 0)
//             {
//                 res.status(404).json({
//                     message: "Account id not found"
//                 });
//             }
//             else res.status(200).json(results[0]);
//         }
//     }

//     model.selectAccountIdByEmail(data, callback);
// }