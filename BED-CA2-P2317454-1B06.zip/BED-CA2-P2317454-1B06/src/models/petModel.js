/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE INSERT OPERATION FOR TASK
// ##############################################################
module.exports.insertPetQuery = (data, callback) => {
    const SQLSTATMENT = `
    INSERT INTO Pet (name, level, cost)
    VALUES (?, ?, ?);
    `;
    const VALUES = [data.name, data.level, data.cost];

    pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR USER
// ##############################################################
module.exports.selectAllPets = (callback) => {
    const SQLSTATEMENT = `
      SELECT * FROM Pet;
    `;
    pool.query(SQLSTATEMENT, callback);

}

// ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR PET
// ##############################################################
module.exports.selectById = (data, callback) => {
    const SQLSTATMENT = `
    SELECT * FROM Pet
    WHERE pet_id = ?;
    `;
    const VALUES = [data.pet_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE UPDATE OPERATIONS FOR TASK
// ##############################################################
module.exports.updateById = (data, callback) => {
    const SQLSTATMENT = `
    UPDATE Pet
    SET name = ?, level = ?, cost = ?
    WHERE pet_id = ?;
    `;
    const VALUES = [data.name, data.level, data.cost, data.pet_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE DELETE OPERATIONS FOR TASK
// ##############################################################
module.exports.deleteById = (data, callback) => {

    const SQLSTATMENT = `
        DELETE FROM Pet
        WHERE pet_id = ?;
    
        ALTER TABLE Task AUTO_INCREMENT = 1;
        `;
    const VALUES = [data.pet_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE CHECK IF VALID PET
// ##############################################################
module.exports.checkIfPetExistQuery = (data, callback) => {
    const SQLSTATMENT = `
    SELECT * FROM PetUserRelationship
    WHERE user_id = ?;
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE CHECK IF VALID LEVEL
// ##############################################################
module.exports.checkIfValidLevelQuery = (data, callback) => {
    const SQLSTATMENT = `

    SELECT * FROM PetAbility
    WHERE level = (SELECT pet_level + 1 FROM PetUserRelationship WHERE pet_id = ? LIMIT 1);
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}


// ##############################################################
// DEFINE UPDATE OPERATIONS FOR PET LEVEL AND ABILITY
// ##############################################################
module.exports.feedPetQuery = (data, callback) => {
    const SQLSTATMENT = `
    UPDATE PetUserRelationship
    SET pet_level = pet_level + 1, 
        ability_id = ability_id + 1
    WHERE pet_id = ?;
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

