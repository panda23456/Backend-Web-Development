/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

//MODEL TO CHECK IF USER_ID AND PET_ID ARE VALID//
module.exports.checkPetAndUserQuery = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT * FROM User WHERE user_id = ?;
  SELECT * FROM Pet WHERE pet_id = ?;
  `;
  const VALUES = [data.user_id, data.pet_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}

//MODEL TO CHECK IF USER CAN AFFORD THE SELECTED PET//
module.exports.checkCostQuery = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT total_points FROM UserPoints WHERE user_id = ?;
        SELECT cost FROM Pet WHERE pet_id = ?;
    `;
  const VALUES = [data.user_id, data.pet_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

//MODEL FOR USER TO BUY PET AND ADD IT TO RELATIONSHIP TABLE'
module.exports.buyPetQuery = (data, callback) => {
  const SQLSTATEMENT = `
  UPDATE UserPoints
  SET total_points = total_points - (
    SELECT cost
    FROM Pet
    WHERE pet_id = ?
  )
  WHERE user_id = ?;

  SET @pet_level := (
    SELECT level
    FROM Pet
    WHERE pet_id = ?
  );

  SET @ability_id := (
    SELECT ability_id
    FROM PetAbility
    WHERE level = (
      SELECT level
      FROM Pet
      WHERE pet_id = ?
    )
  );

  INSERT INTO PetUserRelationship (user_id, pet_id, pet_level, ability_id)
  VALUES (?, ?, @pet_level, @ability_id)
  `;
  const VALUES = [data.pet_id, data.user_id, data.pet_id, data.pet_id, data.user_id, data.pet_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

//MODEL TO CHECK IF USER_ID AND RELATIONSHIP_ID ARE VALID//
module.exports.checkRelationshipAndUserQuery = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT * FROM User WHERE user_id = ?;
  SELECT * FROM PetUserRelationship WHERE (relationship_id, user_id) = (?, ?);
  `;
  const VALUES = [data.user_id, data.relationship_id, data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}

//MODEL TO CHECK IF USER CAN AFFORD TO FEED THE SELECTED PET//
module.exports.checkFeedCostQuery = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT total_points FROM UserPoints WHERE user_id = ?;
    `;
  const VALUES = [data.user_id, data.pet_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

//MODEL TO CHECK IF PET ALREADY REACHED MAX LEVEL//
module.exports.isPetMaxedQuery = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT * FROM PetUserRelationship WHERE relationship_id = ?;
    `;
  const VALUES = [data.relationship_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};


//MODEL TO FEED SELECTED PET OWNED BY USER
module.exports.feedPetQuery = (data, callback) => {
  const SQLSTATEMENT = `
  UPDATE UserPoints
  SET total_points = total_points - 10
  WHERE user_id = ?;

  UPDATE PetUserRelationship
  SET 
      pet_level = pet_level + 1,
      ability_id = ability_id + 1
  WHERE relationship_id = ?;
  `;
  const VALUES = [data.user_id, data.relationship_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

//MODEL FOR getAllUserByUserId
module.exports.selectAllPetByUserId = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT
  PetUserRelationship.relationship_id,
  PetUserRelationship.user_id,
  PetUserRelationship.pet_id,
  PetUserRelationship.pet_level,
  PetUserRelationship.ability_id,
  petAbility.name AS ability_name,
  petAbility.description AS ability_description,
  User.username AS user_username,
  Pet.name AS pet_name
FROM
  PetUserRelationship
JOIN
  petAbility ON PetUserRelationship.ability_id = PetAbility.ability_id
JOIN
  User ON PetUserRelationship.user_id = User.user_id
JOIN
  Pet ON PetUserRelationship.pet_id = Pet.pet_id
WHERE
  PetUserRelationship.user_id = ?;
  `;

  const VALUES = [data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

//MODEL TO DELETE BY RELATIONSHIP ID
module.exports.deleteByRelationshipId = (data, callback) => {
    
  const SQLSTATMENT = `
  DELETE FROM PetUserRelationship WHERE relationship_id = ?;
      `;
  const VALUES = [data.relationship_id];
  
  pool.query(SQLSTATMENT, VALUES, callback);
  }

//   //MODEL TO GET USER ID BY RELATIONSHIP_ID/
// module.exports.selectUserIdByRelationshipId = (data, callback) => {
//   const SQLSTATEMENT = `
//         SELECT user_id FROM PetUserRelationship WHERE relationship_id = ?;
//     `;
//   const VALUES = [data.relationship_id];

//   pool.query(SQLSTATEMENT, VALUES, callback);
// };

// module.exports.getUserIdByPetIdQuery = (data, callback) => {
//   const SQLSTATEMENT = `
//   SELECT user_id FROM PetUserRelationship WHERE pet_id = ?;
// `;
// const VALUES = [data.pet_id];

// pool.query(SQLSTATEMENT, VALUES, callback);
// }