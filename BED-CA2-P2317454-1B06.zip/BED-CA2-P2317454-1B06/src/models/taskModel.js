/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE INSERT OPERATION FOR TASK
// ##############################################################
module.exports.insertTask = (data, callback) => {
    const SQLSTATMENT = `
    INSERT INTO Task (title, description, points)
    VALUES (?, ?, ?);
    `;
const VALUES = [data.title, data.description, data.points];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR TASK
// ##############################################################
module.exports.selectAllTasks = (callback) => {
    const SQLSTATEMENT = `
      SELECT * FROM Task;
    `;
    pool.query(SQLSTATEMENT, callback);
  
  }

  // ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR TASK
// ##############################################################
module.exports.selectById = (data, callback) => {
    const SQLSTATMENT = `
    SELECT * FROM Task
    WHERE task_id = ?;
    `;
    const VALUES = [data.task_id];
  
    pool.query(SQLSTATMENT, VALUES, callback);
  }

  // ##############################################################
// DEFINE UPDATE OPERATIONS FOR TASK
// ##############################################################
module.exports.updateById = (data, callback) => {
    const SQLSTATMENT = `
    UPDATE Task 
    SET title = ?, description = ?, points = ?
    WHERE task_id = ?;
    `;
    const VALUES = [data.title, data.description, data.points, data.task_id];
  
    pool.query(SQLSTATMENT, VALUES, callback);
  }

  // ##############################################################
// DEFINE DELETE OPERATIONS FOR TASK
// ##############################################################
module.exports.deleteById = (data, callback) => {
    
    const SQLSTATMENT = `
        DELETE FROM Task
        WHERE Task_id = ?;
    
        ALTER TABLE Task AUTO_INCREMENT = 1;
        `;
    const VALUES = [data.task_id];
    
    pool.query(SQLSTATMENT, VALUES, callback);
    }

  