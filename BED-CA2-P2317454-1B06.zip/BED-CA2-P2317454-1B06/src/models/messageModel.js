/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

//MODEL TO READ ALL MESSAGES
module.exports.selectAllMessages = (callback) =>
{
    const SQLSTATMENT = `
    SELECT
    Messages.message_id,
    Messages.user_id,
    Messages.message_text,
    User.username AS user_username
FROM
    Messages
JOIN
    User ON Messages.user_id = User.user_id
    `;

    pool.query(SQLSTATMENT, callback);
}

//MODEL TO INSERT NEW MESSAGE TO MESSAGE TABLE
module.exports.insertSingle = (data, callback) =>
{
    const SQLSTATMENT = `
    INSERT INTO Messages (user_id, message_text)
    VALUES (?, ?);
    `;
    const VALUES = [data.user_id, data.message_text];

    pool.query(SQLSTATMENT, VALUES, callback);
}

//MODEL FOR SELECT ALL MESSAGES BY USER ID
module.exports.selectById = (data, callback) =>
{
    const SQLSTATMENT = `
    SELECT
    Messages.message_id,
    Messages.user_id,
    Messages.message_text,
    User.username AS user_username
FROM
    Messages
JOIN
    User ON Messages.user_id = User.user_id
WHERE
    Messages.user_id = ?
    `;
    const VALUES = [data.user_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

//MODEL FOR DELETE MESSAGE BY MESSAGE ID
module.exports.deleteById = (data, callback) =>
{
    const SQLSTATMENT = `
    DELETE FROM Messages 
    WHERE message_id = ?;
    `;
    const VALUES = [data.message_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}

//MODEL TO UPDATE MESSAGE
module.exports.updateById = (data, callback) =>
{
    const SQLSTATMENT = `
    UPDATE Messages 
    SET message_text = ?, user_id = ?
    WHERE message_id = ?;
    `;
    const VALUES = [data.message_text, data.user_id, data.message_id];

    pool.query(SQLSTATMENT, VALUES, callback);
}