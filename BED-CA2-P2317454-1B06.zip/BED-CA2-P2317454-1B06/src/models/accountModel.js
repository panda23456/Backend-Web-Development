/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

//LOGIN MODEL
module.exports.selectUserByUsername = (data, callback) => {
    const SQLSTATEMENT = `SELECT * FROM Account WHERE username = ?`;
    const VALUES = [data.username];
  
    pool.query(SQLSTATEMENT, VALUES, callback);
  }

//REGISTER MODEL
  module.exports.insertUser = (data, callback) => {
    const SQLSTATEMENT = `INSERT INTO Account (username, email, password) VALUES (?, ?, ?)`;
    const VALUES = [data.username, data.email, data.password];
  
    pool.query(SQLSTATEMENT, VALUES, callback);
  };

//checkUsernameOrEmailExist MODEL
module.exports.selectUserByUsernameOrEmail = (data, callback) => {
    const SQLSTATEMENT = `SELECT * FROM Account WHERE username = ? OR email = ?`;
    const VALUES = [data.username, data.email];
  
    pool.query(SQLSTATEMENT, VALUES, callback);
  }
  

  // ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR ACCOUNTS
// ##############################################################
module.exports.selectAllAccounts = (callback) => {
  const SQLSTATEMENT = `
    SELECT * FROM Account;
  `;
  pool.query(SQLSTATEMENT, callback);

}

//MODEL TO UPDATE UserAccountRel
module.exports.addUserAccountRelQuery = (data, callback) => {
  const SQLSTATEMENT = `
    INSERT INTO UserAccountRel (account_id, user_id) VALUES (?, ?);
  `;
  const VALUES = [data.account_id, data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}


//MODEL TO getUserAccountRelById
module.exports.getUserAccountRelByIdQuery = (data, callback) => {
  const SQLSTATEMENT = `
    SELECT
      UserAccountRel.id,
      UserAccountRel.account_id,
      UserAccountRel.user_id,
      Account.username AS account_username,
      User.username AS user_username
    FROM
      UserAccountRel
    JOIN
      Account ON UserAccountRel.account_id = Account.account_id
    JOIN
      User ON UserAccountRel.user_id = User.user_id
    WHERE
      UserAccountRel.account_id = ?;
  `;
  const VALUES = [data.account_id];
  
  pool.query(SQLSTATEMENT, VALUES, callback);
}
// //MODEL TO SELECT ACCOUNT_ID BY EMAIL//
// module.exports.selectAccountIdByEmail = (data, callback) => {
//   const SQLSTATMENT = `
//   SELECT account_id FROM Account
//   WHERE email = ?;
//   `;
//   const VALUES = [data.email];

//   pool.query(SQLSTATMENT, VALUES, callback);
// }