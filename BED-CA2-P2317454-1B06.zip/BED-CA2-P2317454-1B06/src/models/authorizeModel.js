/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

//MODEL TO CHECK IF USER BELONGS TO ACCOUNT//
module.exports.checkUserAccountRelQuery = (data, callback) => {
  const SQLSTATMENT = `
  SELECT * FROM UserAccountRel
WHERE user_id = ? AND account_id = ?;
  `;
  const VALUES = [data.user_id, data.account_id];

  pool.query(SQLSTATMENT, VALUES, callback);
}

//MODEL TO GET USER ID BY RELATIONSHIP_ID/
module.exports.selectUserIdByRelationshipId = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT user_id FROM PetUserRelationship WHERE relationship_id = ?;
    `;
  const VALUES = [data.relationship_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};