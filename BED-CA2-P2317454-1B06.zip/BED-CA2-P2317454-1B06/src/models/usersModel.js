/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE ADD OPERATION FOR USER
// ##############################################################\
module.exports.checkUserQuery = (data, callback) => {
  const SQLSTATMENT = `
  SELECT * FROM User
  WHERE username = ?;

  `;
const VALUES = [data.username];

pool.query(SQLSTATMENT, VALUES, callback);
}

module.exports.addUser = (data, callback) => {
  const SQLSTATMENT = `
  INSERT INTO User (username)
  VALUES (?);

  `;
const VALUES = [data.username];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT ALL OPERATIONS FOR USER
// ##############################################################
  module.exports.selectAllUsers = (callback) => {
  const SQLSTATEMENT = `
    SELECT * FROM User;
  `;
  pool.query(SQLSTATEMENT, callback);

}

// ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR USER
// ##############################################################
module.exports.selectById = (data, callback) => {
  const SQLSTATEMENT = `
    SELECT User.user_id, username, total_points
    FROM User
    LEFT JOIN UserPoints ON User.user_id = UserPoints.user_id
    WHERE User.user_id = ?;
  `;

  const VALUES = [data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
};

// ##############################################################
// DEFINE UPDATE OPERATIONS FOR USER
// ##############################################################
module.exports.updateById = (data, callback) => {
  const SQLSTATMENT = `
  UPDATE User 
  SET username = ?
  WHERE user_id = ?;
  `;
  const VALUES = [data.username, data.user_id];

  pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE DELETE OPERATIONS FOR USER
// ##############################################################
module.exports.deleteById = (data, callback) => {
    
  const SQLSTATMENT = `
  DELETE FROM User WHERE user_id = ?;
  DELETE FROM TaskProgress WHERE user_id = ?;
  DELETE FROM UserPoints WHERE user_id = ?;
  DELETE FROM PetUserRelationship WHERE user_id = ?;
  DELETE FROM UserAccountRel WHERE user_id = ?;
  DELETE FROM Messages WHERE user_id = ?;
      `;
  const VALUES = [data.user_id, data.user_id, data.user_id, data.user_id, data.user_id, data.user_id];
  
  pool.query(SQLSTATMENT, VALUES, callback);
  }

  // ##############################################################
// DEFINE DELETE OPERATIONS FOR GET TASK ID
// ##############################################################
module.exports.getTaskIdQuery = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT task_id FROM TaskProgress
  WHERE user_id = ?;
  `;
  const VALUES = [data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}

// ##############################################################
// DEFINE DELETE OPERATIONS FOR GET POINTS
// ##############################################################
module.exports.getPointsQuery = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT COALESCE(SUM(points), 0) as totalPoints FROM Task
  WHERE task_id IN (?);
  `;
  const taskIds = data.tasks.map(task => task.task_id);
  const VALUES = [taskIds];

  pool.query(SQLSTATEMENT, VALUES, callback);
}



// ##############################################################
// DEFINE INSERT OPERATION FOR CHECKING PET
// ##############################################################

module.exports.checkPetAndUserQuery = (data, callback) => {
  const SQLSTATEMENT = `
  SELECT * FROM Pet WHERE pet_id = ?;
  SELECT * FROM User WHERE user_id = ?;
  `;
  const VALUES = [data.pet_id, data.user_id];

  pool.query(SQLSTATEMENT, VALUES, callback);
}

// ##############################################################
// DEFINE INSERT OPERATION FOR CHECKING COST
// ##############################################################
module.exports.checkCostQuery = (data, callback) => {
  const SQLSTATEMENT = `
        SELECT total_points FROM UserPoints WHERE user_id = ?;
        SELECT cost FROM Pet WHERE pet_id = ?;
    `;
    const VALUES = [data.user_id, data.pet_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};

// ##############################################################
// DEFINE INSERT OPERATION FOR BUYING PET
// ##############################################################
module.exports.buyPetQuery = (data, callback) => {
  const SQLSTATEMENT = `
  UPDATE UserPoints
  SET total_points = total_points - (
    SELECT cost
    FROM Pet
    WHERE pet_id = ?
  )
  WHERE user_id = ?;

  SET @ability_id := (
    SELECT ability_id
    FROM PetAbility
    WHERE level = (
      SELECT level
      FROM Pet
      WHERE pet_id = ?
    )
  );

  SET @pet_level := (
    SELECT level
    FROM Pet
    WHERE pet_id = ?
  );

  INSERT INTO PetUserRelationship (user_id, pet_id, pet_level, ability_id)
  VALUES (?, ?, @pet_level, @ability_id)
  `;
  const VALUES = [data.pet_id, data.user_id, data.pet_id, data.pet_id, data.user_id, data.pet_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
};