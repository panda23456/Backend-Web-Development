/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const pool = require("../services/db");

// ##############################################################
// DEFINE INSERT OPERATION FOR TAsk PROGRESS
// ##############################################################

module.exports.checkTaskIds = (data, callback) => {
    const SQLSTATEMENT = `
    SELECT * FROM User WHERE user_id = ?;
    SELECT * FROM Task WHERE task_id = ?;
    `;
    const VALUES = [data.user_id, data.task_id];

    pool.query(SQLSTATEMENT, VALUES, callback);
}

module.exports.insertTask = (data, callback) => {
    const SQLSTATMENT = `
    INSERT INTO TaskProgress (user_id, task_id, completion_date, notes)
    VALUES (?, ?, ?, ?);
    `;
const VALUES = [data.user_id, data.task_id, data.completion_date, data.notes];

pool.query(SQLSTATMENT, VALUES, callback);
}

// ##############################################################
// DEFINE SELECT BY ID OPERATIONS FOR TASK PROGRESS
// ##############################################################
module.exports.selectById = (data, callback) => {
    const SQLSTATMENT = `
    SELECT * FROM TaskProgress
    WHERE progress_id = ?;
    `;
    const VALUES = [data.id];
  
    pool.query(SQLSTATMENT, VALUES, callback);
  }

  // ##############################################################
// DEFINE UPDATE OPERATIONS FOR TASK
// ##############################################################
  module.exports.updateById = (data, callback) => {
    const SQLSTATMENT = `
    UPDATE TaskProgress 
    SET notes = ?
    WHERE progress_id = ?;
    `;
    const VALUES = [data.notes, data.progress_id];
  
    pool.query(SQLSTATMENT, VALUES, callback);
  }

  // ##############################################################
// DEFINE DELETE OPERATIONS FOR TASK PROGRESS
// ##############################################################
module.exports.deleteById = (data, callback) => {
    
    const SQLSTATMENT = `
        DELETE FROM TaskProgress
        WHERE progress_id = ?;
    
        ALTER TABLE TaskProgress AUTO_INCREMENT = 1;
        `;
    const VALUES = [data.progress_id];
    
    pool.query(SQLSTATMENT, VALUES, callback);
    }

//MODEL TO GET TASK POINTS FROM TASK COMPLETED

module.exports.getPoints = (data, callback) => {
  const SQLSTATMENT = `
  SELECT points FROM Task
  WHERE task_id = ?;
  `;
  const VALUES = [data.task_id];

  pool.query(SQLSTATMENT, VALUES, callback);
}


//MODEL TO ADD TASK POINTS TO USER POINTS
module.exports.addPoints = (data, points, callback) => {
  const SQLSTATMENT = `
  INSERT INTO UserPoints (user_id, total_points)
  VALUES (?, ?)
  ON DUPLICATE KEY UPDATE total_points = total_points + ?;
  `;
  const VALUES = [data.user_id, points, points];

  pool.query(SQLSTATMENT, VALUES, callback);
}
  