/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');

// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();
const controller = require('../controllers/petController');
const jwtMiddleware = require('../middlewares/jwtMiddleware');

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.post('/', jwtMiddleware.verifyToken, controller.createPet);
router.get('/', jwtMiddleware.verifyToken, controller.readAllPet);
router.get('/home', controller.readAllPet);
router.get('/:pet_id', jwtMiddleware.verifyToken, controller.readPetById);
router.put('/:pet_id', jwtMiddleware.verifyToken, controller.updatePetById)
router.delete("/:pet_id", jwtMiddleware.verifyToken, controller.deletePetById)
// router.get('/:user_id/:pet_id/feed', controller.checkIfPetExist, controller.checkIfValidLevel, controller.feedPet)

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;