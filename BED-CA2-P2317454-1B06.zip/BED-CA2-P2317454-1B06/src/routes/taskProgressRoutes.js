/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');

// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();
const controller = require('../controllers/taskProgressController');

// ##############################################################
// DEFINE ROUTES
// ##############################################################
//BELOW URL POSTS TASK PROGRESS AND ADD TASK POINTS TO USER POINTS
router.post('/', controller.checkTaskProgress, controller.addTaskProgress, controller.getTaskPoints, controller.addTaskPoints);
router.get('/:progress_id', controller.readTaskProgressById);
router.put('/:progress_id', controller.updateTaskProgressById)
router.delete("/:progress_id", controller.deleteTaskProgressById) 

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;