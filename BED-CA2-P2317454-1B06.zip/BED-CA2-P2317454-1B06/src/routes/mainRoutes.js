/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');


// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();

// ##############################################################
// DEFINE ROUTES
// ##############################################################
const usersRoutes = require('./usersRoutes');
const taskRoutes = require('./taskRoutes');
const taskProgressRoutes = require('./taskProgressRoutes');
const petRoutes = require('./petRoutes');
const petUserRoutes = require('./petUserRoutes');
const accountRoutes = require('./accountRoutes');
const messageRoutes = require('./messageRoutes');
const authorizeRoutes = require('./authorizeRoutes')

const jwtMiddleware = require('../middlewares/jwtMiddleware');
const bcryptMiddleware = require('../middlewares/bcryptMiddleware');
const accountController = require('../controllers/accountController');

router.use("/users", usersRoutes);
router.use("/tasks", taskRoutes);
router.use("/task_progress", jwtMiddleware.verifyToken, taskProgressRoutes);
router.use("/pets", petRoutes);
router.use("/petUser", jwtMiddleware.verifyToken, petUserRoutes);
router.use("/account", accountRoutes);
router.use("/message", messageRoutes);
router.use("/authorize", authorizeRoutes)

router.post("/login", accountController.login, bcryptMiddleware.comparePassword, jwtMiddleware.generateToken, jwtMiddleware.sendToken);
router.post("/register", accountController.checkUsernameOrEmailExist, bcryptMiddleware.hashPassword, accountController.register, jwtMiddleware.generateToken, jwtMiddleware.sendToken);


// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;