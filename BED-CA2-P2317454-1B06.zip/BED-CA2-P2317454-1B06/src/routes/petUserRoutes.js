/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');

// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();
const controller = require('../controllers/petUserController');

// ##############################################################
// DEFINE ROUTES
// ##############################################################
//URL TO BUY PET
router.get('/user/:user_id/pet/:pet_id/buy', controller.checkValidPetAndUser, controller.checkCost, controller.buyPet)
router.get('/user/:user_id/relationship/:relationship_id/feed', controller.checkValidRelationshipAndUser, controller.checkFeedCost,
controller.isPetMaxed, controller.feedPet)//feeding pet costs 10 Money
router.get('/:user_id', controller.getAllPetByUserId)
// router.get('/relationship/:relationship_id', controller.getUserIdByRelationshipId)
router.delete('/:relationship_id', controller.deletPetByRelationshipId)
// router.get('/user/:user_id/pet/:pet_id', controller.checkValidPetAndUser, controller.getUserIdByPetId)

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;