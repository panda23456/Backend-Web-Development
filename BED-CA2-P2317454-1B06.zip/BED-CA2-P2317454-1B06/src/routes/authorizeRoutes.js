/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');

// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();
const controller = require('../controllers/authorizeController');
const jwtMiddleware = require('../middlewares/jwtMiddleware');

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.get('/:user_id', jwtMiddleware.verifyToken, controller.checkUserAccountRel);
router.get('/relationship/:relationship_id', jwtMiddleware.verifyToken, controller.getUserIdByRelId, controller.checkUserAccountRel)
// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;