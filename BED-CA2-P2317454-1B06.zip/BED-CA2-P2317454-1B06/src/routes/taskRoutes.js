/*
  Author: Loh Yip Khai
  Class: DAAA/1B/06
  Admission Number: p2317454
*/

// ##############################################################
// REQUIRE MODULES
// ##############################################################
const express = require('express');

// ##############################################################
// CREATE ROUTER
// ##############################################################
const router = express.Router();
const controller = require('../controllers/taskController');
const jwtMiddleware = require('../middlewares/jwtMiddleware');

// ##############################################################
// DEFINE ROUTES
// ##############################################################
router.post('/', jwtMiddleware.verifyToken, controller.addTask);
router.get('/home', controller.readAllTasks)
router.get('/', jwtMiddleware.verifyToken, controller.readAllTasks)
router.get('/:task_id', jwtMiddleware.verifyToken, controller.readTaskById)
router.put('/:task_id', jwtMiddleware.verifyToken, controller.updateTaskById)
router.delete('/:task_id', jwtMiddleware.verifyToken, controller.deleteTaskById)

// ##############################################################
// EXPORT ROUTER
// ##############################################################
module.exports = router;