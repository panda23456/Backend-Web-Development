document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const petId = urlParams.get("pet_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {
        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus)

        const petBought = document.getElementById("petBought");

        petBought.innerHTML = `
            ${responseData.message}  
          `;

          delayRedirect("singleUserInfo.html?user_id=", userId)
    }

    buyPetUrl = currentUrl + `/api/petUser/user/${userId}/pet/${petId}/buy`
    fetchMethod(buyPetUrl, callback, method = "GET", data = null, token);
});
