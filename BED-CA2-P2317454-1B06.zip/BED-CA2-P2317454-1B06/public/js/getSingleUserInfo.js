document.addEventListener("DOMContentLoaded", function () {
  url = new URL(document.URL);
  const urlParams = url.searchParams;
  const userId = urlParams.get("user_id");

  const token = localStorage.getItem("token");

  // console.log("potato ")

  authorizeUserAccount(userId, token);

    const callbackForUserInfo = (responseStatus, responseData) => {
      console.log("responseStatus:", responseStatus);
      console.log("responseData:", responseData);

      checkToken(responseStatus);

      const singleUserInfo = document.getElementById("singleUserInfo");

      if (responseStatus == 404) {
        singleUserInfo.innerHTML = `${responseData.message}`;
        return;
      }

      singleUserInfo.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                    User ID: ${responseData.user_id} <br>
                        Player Username: ${responseData.username} <br>
                        Player Total Points: ${responseData.total_points} <br>
                    </p>
                </div>
            </div>
            
            <div class="button-container" style="margin-bottom: 20px;">
              <a href="users.html" class="btn btn-primary">Go Back</a>
            </div>

            <div class="card">
          <div class="card-body">
            <h5 class="card-title">User Actions</h5>
            <p class="card-text">Choose an action:</p>
            <a href="changeUsername.html?user_id=${userId}" class="btn btn-primary" style="background-color: #3498db;">Change Username</a>
            <a href="deleteUser.html?user_id=${userId}" class="btn btn-primary" style="background-color: #e74c3c; margin-left: 10px;">Delete User</a>
            <a href="taskInfo.html?user_id=${userId}" class="btn btn-primary" style="background-color: #2ecc71; margin-left: 10px;">Peform Task</a>
            <a href="petInfo.html?user_id=${userId}" class="btn btn-primary" style="background-color: #f39c12; margin-left: 10px;">Buy Pet</a>
            <a href="choosePetToFeed.html?user_id=${userId}" class="btn btn-primary" style="margin-left: 10px;">Feed Pet</a>
            <a href="postMessage.html?user_id=${userId}" class="btn btn-primary" style="margin-left: 10px;">Post Message</a>
            <a href="deletePet.html?user_id=${userId}" class="btn btn-primary" style="margin-left: 10px;">Delete Pet</a>
            <a href="updateUserMessage.html?user_id=${userId}" class="btn btn-primary" style="margin-left: 10px;">Update Message</a>
          </div>
        </div>
        `;


      const anotherCallback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        //verify token
        checkToken(responseStatus);

        const userPetList = document.getElementById("userPetList");

        //displays error message if nothing is found
        doesUserOwn(responseData.message, userPetList) ;

        responseData.forEach((Pet) => {
          const displayItem = document.createElement("div");
          displayItem.className =
            "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
          displayItem.innerHTML = `
            <div class="card">
            <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Pet.pet_id}.png" class="card-img-top" alt="Pokemon Image">
                <div class="card-body">
                    <h5 class="card-title">NAME: ${Pet.pet_name}</h5>
                    <p class="card-text">
                        PET LEVEL: ${Pet.pet_level} <br>
                        PET ABILITY: ${Pet.ability_name} <br>
                        (${Pet.ability_description})
                    </p>
                </div>
            </div>
            `;
          userPetList.appendChild(displayItem);
        });
      }
      fetchMethod(currentUrl + `/api/petUser/${userId}`, anotherCallback, method = "GET", data = null, token);

    }
    fetchMethod(currentUrl + `/api/users/${userId}`, callbackForUserInfo, method = "GET", data = null, token);
  

});