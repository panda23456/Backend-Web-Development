document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        const deleteCompletion = document.getElementById("deleteCompletion");

        deleteCompletion.innerHTML = `
            ${responseData.message} <br>
          `;
    }
    fetchMethod(currentUrl + `/api/users/${userId}`, callback, method = "DELETE", data = null, token);
});