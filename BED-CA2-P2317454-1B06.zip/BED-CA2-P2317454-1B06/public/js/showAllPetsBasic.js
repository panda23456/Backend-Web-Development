const callback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);
  
    const petList = document.getElementById("petList");

    responseData.forEach((Pet) => {
      const displayItem = document.createElement("div");
      displayItem.className =
        "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
      displayItem.innerHTML = `
          <div class="card">
          <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Pet.pet_id}.png" class="card-img-top" alt="Pokemon Image">
              <div class="card-body">
                  <h5 class="card-title">ID: ${Pet.pet_id}</h5>
                  <p class="card-text">
                      NAME: ${Pet.name} <br>
                      LEVEL: ${Pet.level} <br>
                      COST: ${Pet.cost} <br>
                  </p>
              </div>
          </div>
          `;
      petList.appendChild(displayItem);
    });
  };
  
  fetchMethod(currentUrl + "/api/pets/home", callback);

//   //Async function to get user_id based on pet_id
// async function getUserIDByPetID(pet_id) {
//   // Make an API call or database query to get the user_id based on pet_id
//   // For example, you might use fetch or axios to request the data from the server
//   const response = await fetch(`${currentUrl}/api/petUserRelationship/${pet_id}`);
//   const data = await response.json();mj8
//   return data.user_id;
// }

// async function getUserIDByPetID(pet_id) {
//     // Make an API call using fetchMethod to get the user_id based on pet_id
//     const url = `${currentUrl}/api/petUserRelationship/${pet_id}`;
//     const callback = (status, data) => {
//         if (status === 200) {
//             return data.user_id;
//         } else {
//             // Handle error if needed
//             console.error(`Error from GET ${url}:`, data);
//             return null;
//         }
//     };

//     // Use fetchMethod to make the API call
//     await fetchMethod(url, callback);
//   }
