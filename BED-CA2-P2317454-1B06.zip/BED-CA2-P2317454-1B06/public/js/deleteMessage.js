document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const messageId = urlParams.get("message_id");
    const token = localStorage.getItem("token");

    console.log(messageId)

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        const deleteMessage = document.getElementById("deleteMessage");

        deleteMessage.innerHTML = `
            ${responseData.message} <br>
          `;
    }
    fetchMethod(currentUrl + `/api/message/${messageId}`, callback, method = "DELETE", data = null, token);
});