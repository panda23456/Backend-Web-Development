document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const relationshipId = urlParams.get("relationship_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        const feedCompletion = document.getElementById("feedCompletion");

        feedCompletion.innerHTML = `
            ${responseData.message} <br>
          `;

          delayRedirect("singleUserInfo.html?user_id=", userId)
    }
    fetchMethod(currentUrl + `/api/petUser/user/${userId}/relationship/${relationshipId}/feed`, callback, method = "GET", data = null, token);
});