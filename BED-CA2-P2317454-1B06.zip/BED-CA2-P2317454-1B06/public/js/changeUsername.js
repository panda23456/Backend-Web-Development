document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {
        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        if (responseStatus == 201) {
            // Check if login was successful
            successCard.classList.remove("d-none");
            successText.innerText = "Username Updated";

            delayRedirect("singleUserInfo.html?user_id=", userId)
        } else if (responseStatus == 409) {
            warningCard.classList.remove("d-none");
            warningText.innerText = responseData.message;
        } else {
            warningCard.classList.remove("d-none");
            warningText.innerText = "Error occured";
        }
    };

    const updateUserForm = document.getElementById("updateUserForm");

    const warningCard = document.getElementById("warningCard");
    const warningText = document.getElementById("warningText");

    const successCard = document.getElementById("successCard");
    const successText = document.getElementById("successText");

    updateUserForm.addEventListener("submit", function (event) {
        console.log("updateUserForm.addEventListener");
        event.preventDefault();

        const username = document.getElementById("username").value;

        const data = {
            username: username
        };

        // Perform login request
        fetchMethod(currentUrl + `/api/users/${userId}`, callback, "PUT", data, token);

        // Reset the form fields
        updateUserForm.reset();
        warningCard.classList.add("d-none");
        successCard.classList.add("d-none");
    });
});