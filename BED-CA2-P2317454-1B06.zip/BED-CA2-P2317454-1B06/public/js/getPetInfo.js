document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    // const userPoints = urlParams.get("user_points");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const firstCallback = (responseStatus, responseData) => {
        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        //Insert userPoints into html page
        const userPointBalanceElement = document.getElementById("userPointBalance");
        userPointBalanceElement.textContent = `${responseData.total_points}`;

        const callback = (responseStatus, responseData) => {
            console.log("responseStatus:", responseStatus);
            console.log("responseData:", responseData);

            checkToken(responseStatus);

            // //Insert userPoints into html page
            // const userPointBalanceElement = document.getElementById("userPointBalance");
            // userPointBalanceElement.textContent = userPoints.toString();

            //Prints out all pets
            const petList = document.getElementById("petList");

            responseData.forEach((Pet) => {
                const displayItem = document.createElement("div");
                displayItem.className =
                    "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
                displayItem.innerHTML = `
          <div class="card">
          <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Pet.pet_id}.png" class="card-img-top" alt="Pokemon Image">
              <div class="card-body">
                  <p class="card-text">
                      NAME: ${Pet.name} <br>
                      LEVEL: ${Pet.level} <br>
                      COST: ${Pet.cost} <br>
                  </p>
                  <a href="petBought.html?user_id=${userId}&pet_id=${Pet.pet_id}" class="btn btn-primary" style="margin-left: 10px;">Buy Pet (${Pet.cost} pts)</a>
              </div>
          </div>
          `;
                petList.appendChild(displayItem);
            });
        };
        fetchMethod(currentUrl + "/api/pets", callback, method = "GET", data = null, token);
    }
    fetchMethod(currentUrl + `/api/users/${userId}`, firstCallback, method = "GET", data = null, token);
});