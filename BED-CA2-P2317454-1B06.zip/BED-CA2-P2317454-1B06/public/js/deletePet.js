document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");

    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const anotherCallback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        //verify token
        checkToken(responseStatus);

        const deletePet = document.getElementById("deletePet");

        //displays error message if nothing is found
        doesUserOwn(responseData.message, deletePet);

        responseData.forEach((Pet) => {
            const displayItem = document.createElement("div");
            displayItem.className =
                "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
            displayItem.innerHTML = `
            <div class="card">
            <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${Pet.pet_id}.png" class="card-img-top" alt="Pokemon Image">
                <div class="card-body">
                    <h5 class="card-title">NAME: ${Pet.pet_name}</h5>
                    <p class="card-text">
                        PET LEVEL: ${Pet.pet_level} <br>
                        PET ABILITY: ${Pet.ability_name} <br>
                        (${Pet.ability_description})
                    </p>
                    <a href="deletePetCompletion.html?relationship_id=${Pet.relationship_id}&user_id=${userId}" class="btn btn-primary" style="margin-left: 10px;">Delete</a>
                </div>
            </div>
            `;
            deletePet.appendChild(displayItem);
        });
    }
    fetchMethod(currentUrl + `/api/petUser/${userId}`, anotherCallback, method = "GET", data = null, token);

});