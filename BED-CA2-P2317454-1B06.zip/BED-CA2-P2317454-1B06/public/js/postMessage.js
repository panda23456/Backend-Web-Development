document.addEventListener("DOMContentLoaded", function () {
  url = new URL(document.URL);
  const urlParams = url.searchParams;
  const userId = urlParams.get("user_id");
  const token = localStorage.getItem("token");

  if (token == null) {
    window.location.href = "invalidToken.html";
    return;
}

  authorizeUserAccount(userId, token);

  const callback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    checkToken(responseStatus);

    if (responseStatus == 201) {
      // Check if login was successful
      successCard.classList.remove("d-none");
      successText.innerText = "Message Posted";
      delayRedirect("singleUserInfo.html?user_id=", userId)
    } else {
      warningCard.classList.remove("d-none");
      warningText.innerText = "Error occured";
    }
  };

  const postMessageForm = document.getElementById("postMessageForm");
  
    const warningCard = document.getElementById("warningCard");
    const warningText = document.getElementById("warningText");

    const successCard = document.getElementById("successCard");
    const successText = document.getElementById("successText");

    postMessageForm.addEventListener("submit", function (event) {
      console.log("postMessageForm.addEventListener");
      event.preventDefault();
  
      const message = document.getElementById("messageText").value;
  
      const data = {
        user_id: userId,
        message_text: message,
      };

      // Perform login request
      fetchMethod(currentUrl + "/api/message", callback, "POST", data, token);
  
      // Reset the form fields
      postMessageForm.reset();
      warningCard.classList.add("d-none");
      successCard.classList.add("d-none");
    });
});