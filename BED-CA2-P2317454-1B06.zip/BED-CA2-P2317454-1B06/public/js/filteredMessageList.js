document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");

const callback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);
  
    const filteredMessageList = document.getElementById("filteredMessageList");
    // const buttonList = document.getElementById("buttonList")

    // doesUserOwn(responseData.message, filteredMessageList);

    responseData.forEach((Message) => {
      const displayItem = document.createElement("div");
      displayItem.className =
        "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
      displayItem.innerHTML = `
          <div class="card">
          <div class="card-body">
          <h5 class="card-title">User: ${Message.user_username}</h5>
          <p class="card-text">
              Message: ${Message.message_text} <br>
          </p>
      </div>
          </div>
          `;
      filteredMessageList.appendChild(displayItem);
    });
    
  };
  fetchMethod(currentUrl + `/api/message/${userId}`, callback);
});
  
  