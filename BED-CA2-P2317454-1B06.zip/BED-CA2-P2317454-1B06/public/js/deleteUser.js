document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);


    const callback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        const deleteUser = document.getElementById("deleteUser");

        deleteUser.innerHTML = `
            Are you sure you want to delete User: ${responseData.username} <br>
            <a href="users.html" class="btn btn-primary">Go Back</a>
            <a href="deleteCompletion.html?user_id=${userId}" class="btn btn-primary">DELETE</a
          `;
    }
    fetchMethod(currentUrl + `/api/users/${userId}`, callback, method = "GET", data = null, token);
});