function checkToken(responseStatus) {
  // Additional check for token expiration
  if (responseStatus == 401) {
    // Token is expired, redirect to login
    localStorage.removeItem("token");
    localStorage.removeItem("account_id");
    window.location.href = "invalidToken.html";
    return;
  }
}

function authorizeUserAccount(userId, token) {
  // console.log("User ID:", userId);
  //   console.log("Token:", token);

  const authorizeCallback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    if (responseStatus == 404) {
      console.log(responseData.message)
      window.location.href = "unauthorizedAccess.html";
      return;
    }

  }
  fetchMethod(currentUrl + `/api/authorize/${userId}`, authorizeCallback, method = "GET", data = null, token)
}

function doesUserOwn(message, element) {
  if (message) {
    element.innerHTML = `
  <div class="card">
      <div class="card-body">
          <p class="card-text">
          ${message} <br>
          </p>
      </div>
  </div>
  `;
  }
}

function delayRedirect(url, userId) {
  setTimeout(() => {
    window.location.href = `${url}${userId}`;
  }, 1000);
}

function authorizeUserRelationship(relationshipId, token) {
  // console.log("User ID:", userId);
  //   console.log("Token:", token);

  const anotherCallback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    if (responseStatus == 404) {
      console.log(responseData.message)
      window.location.href = "unauthorizedAccess.html";
      return;
    }

  }
  fetchMethod(currentUrl + `/api/authorize/relationship/${relationshipId}`, anotherCallback, method = "GET", data = null, token)
}


// function getUserId(relationship_id, token) {
//   const callback = (responseStatus, responseData) => {

//     console.log("responseStatus:", responseStatus);
//     console.log("responseData:", responseData);

//     checkToken(responseStatus);

//     return responseData[0].user_id;
//   }
//   fetchMethod(currentUrl + `/api/petUser/relationship/${relationship_id}`, callback, method = "GET", data = null, token);
// }