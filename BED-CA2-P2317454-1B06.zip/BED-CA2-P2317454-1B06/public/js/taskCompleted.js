document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const userId = urlParams.get("user_id");
    const taskId = urlParams.get("task_id");
    const token = localStorage.getItem("token");

    authorizeUserAccount(userId, token);

    const callback = (responseStatus, responseData) => {
        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        delayRedirect("singleUserInfo.html?user_id=", userId);
    }

    const data = {
        user_id : userId,
        task_id: taskId,
        completion_date: new Date().toISOString().split('T')[0],
        notes: `Task ${taskId} completed`,
    }

    fetchMethod(currentUrl + `/api/task_progress`, callback, "POST", data, token)
});
