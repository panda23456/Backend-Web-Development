document.addEventListener("DOMContentLoaded", function () {
    url = new URL(document.URL);
    const urlParams = url.searchParams;
    const relationshipId = urlParams.get("relationship_id");
    const userId = urlParams.get("user_id");

    //FIX THE 
    const token = localStorage.getItem("token");
    
    authorizeUserAccount(userId, token)
    authorizeUserRelationship(relationshipId, token);

    const callback = (responseStatus, responseData) => {

        console.log("responseStatus:", responseStatus);
        console.log("responseData:", responseData);

        checkToken(responseStatus);

        const petDeleted = document.getElementById("petDeleted");

        petDeleted.innerHTML = `
            ${responseData.message} <br>
          `;
          
          delayRedirect("singleUserInfo.html?user_id=", userId)
    }
    fetchMethod(currentUrl + `/api/petUser/${relationshipId}`, callback, method = "DELETE", data = null, token);
});