const callback = (responseStatus, responseData) => {
  console.log("responseStatus:", responseStatus);
  console.log("responseData:", responseData);

  const taskList = document.getElementById("taskList");
  responseData.forEach((Task) => {
    // // // Assuming there's an async function to fetch user_id based on pet_id
    // const user_id = await getUserIDByPetID(Pet.pet_id);

    const displayItem = document.createElement("div");
    displayItem.className =
      "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
    displayItem.innerHTML = `
          <div class="card">
              <div class="card-body">
                  <h5 class="card-title">Task: ${Task.task_id}</h5>
                  <p class="card-text">
                      TITLE: ${Task.title} <br>
                      DESCRIPTION: ${Task.description} <br>
                      POINTS: ${Task.points} <br>
                  </p>
              </div>
          </div>
          `;
    taskList.appendChild(displayItem);
  });
};

fetchMethod(currentUrl + "/api/tasks/home", callback);