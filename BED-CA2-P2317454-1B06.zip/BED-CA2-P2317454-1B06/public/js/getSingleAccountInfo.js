document.addEventListener("DOMContentLoaded", function () {
  url = new URL(document.URL);
  const urlParams = url.searchParams;
  const accountId = urlParams.get("account_id");

  console.log("potato ")

  const callbackForUserInfo = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    const singleAccountInfo = document.getElementById("singleAccountInfo");

    doesUserOwn(responseData.message, singleAccountInfo);

    responseData.forEach((User) => {
      const displayItem = document.createElement("div");
      displayItem.className =
        "col-xl-2 col-lg-3 col-md-4 col-sm-6 col-xs-12 p-3";
      displayItem.innerHTML = `
      <div class="card">
          <div class="card-body">
              <h5 class="card-title">Username:</h5>
                  <p class="card-text">
                      ${User.user_username}
                  </p>
          </div>
      </div>
      `;
      singleAccountInfo.appendChild(displayItem);
    });
  }
    fetchMethod(currentUrl + `/api/account/${accountId}/home`, callbackForUserInfo);
  
});