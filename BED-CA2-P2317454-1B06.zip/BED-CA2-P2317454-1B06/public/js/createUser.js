document.addEventListener("DOMContentLoaded", function () {
  const token = localStorage.getItem("token")

  if (token == null) {
    window.location.href = "invalidToken.html";
    return;
}
// Check if the user is logged in
if (token) {
  // Check if the message has already been shown
  const hasSeenSuccessMessage = localStorage.getItem("hasSeenSuccessMessage");

  if (!hasSeenSuccessMessage) {
    // Show the success message
    showSuccessMessage();
    // Mark that the user has seen the success message
    localStorage.setItem("hasSeenSuccessMessage", "true");
  }
}

  const callback = (responseStatus, responseData) => {
    console.log("responseStatus:", responseStatus);
    console.log("responseData:", responseData);

    checkToken(responseStatus);

    if (responseStatus == 201) {
      // Check if login was successful
      console.log("Created user successfully")
      successCard.classList.remove("d-none");
      successText.innerText = "Successful user creation"

      //Code to fetch updateUserAccountRel api
      if (responseData.user_id) {// check if there is a user_id generated for new user
        // Another callback function for the second fetchMethod
        const anotherCallback = (anotherResponseStatus, anotherResponseData) => {
          console.log("Another responseStatus:", anotherResponseStatus);
          console.log("Another responseData:", anotherResponseData);
        }

        //url to updateUserAccountRel
        const updateUserAccountRelUrl = currentUrl + "/api/account"
        accountId = localStorage.getItem("account_id");
        userId = responseData.user_id;

        //Store account and user id into variables
        const anotherData = {
          account_id: accountId,
          user_id: userId
        };

        fetchMethod(updateUserAccountRelUrl, anotherCallback, "POST", anotherData, token);

        // // Redirect or perform further actions for logged-in user
        // window.location.href = "profile.html";
      }
    } else {
      warningCard.classList.remove("d-none");
      warningText.innerText = responseData.message;
    }
  };

  const createUserForm = document.getElementById("createUserForm");

  const warningCard = document.getElementById("warningCard");
  const warningText = document.getElementById("warningText");

  const successCard = document.getElementById("successCard");
  const successText = document.getElementById("successText");

  createUserForm.addEventListener("submit", function (event) {
    console.log("createUserForm.addEventListener");
    event.preventDefault();

    const username = document.getElementById("username").value;

    const data = {
      username: username,
    };

    // Perform create newUser request
    fetchMethod(currentUrl + "/api/users", callback, "POST", data, token);
    // fetchMethod(currentUrl + "/api/Account/${data.email}", callback, data);

    // Reset the form fields and warning, success cards
    warningCard.classList.add("d-none");
    successCard.classList.add("d-none");
    createUserForm.reset();
  });

  function showSuccessMessage() {
    const accountSuccess = document.getElementById("accountSuccess");

    // Set the text content of the element
    accountSuccess.innerText = "Account Login Successful";

    // Make the element visible
    accountSuccess.classList.remove("d-none");
  }
});


